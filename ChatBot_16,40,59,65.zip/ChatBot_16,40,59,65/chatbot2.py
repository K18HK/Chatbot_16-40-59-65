import io
import random
import string # to process standard python strings
import warnings
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import warnings
warnings.filterwarnings('ignore')

import nltk
from nltk.stem import WordNetLemmatizer
#nltk.download('popular', quiet=True) # for downloading popular packages
#nltk.download('punkt') 
#nltk.download('wordnet') 
f=open('/home/user/Desktop/chatbot.txt','r')
raw=f.read()
raw = raw.lower()# converts to lowercase

sent_tokens = nltk.sent_tokenize(raw)#this will convert the list to sentences
word_tokens = nltk.word_tokenize(raw)#this will convert the list to words

lemmer = nltk.stem.WordNetLemmatizer()  
#in NLTK, Wordnet is a semintically oriented dictionary in english.
def LemTokens(tokens):
    return [lemmer.lemmatize(token) for token in tokens]
remove_punct_dict = dict((ord(punct), None) for punct in string.punctuation)

def LemNormalize(text):
    return LemTokens(nltk.word_tokenize(text.lower().translate(remove_punct_dict)))

INPUTS_GREETS = ("hello", "hi", "greetings", "sup", "what's up","hey","hola")
RESPONSES_GREETS = ["hi", "hey", "*nods*", "hi there", "hello", "I am glad! You are talking to me"]
def greeting(sentence):
 
    for word in sentence.split():
        if word.lower() in INPUTS_GREETS:
            return random.choice(RESPONSES_GREETS)
INPUTS_GREETS2 = ("How are you?","How are you doing?")
RESPONSES_GREETS2 = ["I am doing good, I hope you too are !!","I am great,I hope you too are."]
def greetingss(sentence):
 
    for word in sentence.split():
        if word.lower() in INPUTS_GREETS2:
            return random.choice(RESPONSES_GREETS2)
        
def response(user_response):
    robo_response=''
    sent_tokens.append(user_response)
    TfidfVec = TfidfVectorizer(tokenizer=LemNormalize, stop_words='english')
    tfidf = TfidfVec.fit_transform(sent_tokens)
    vals = cosine_similarity(tfidf[-1], tfidf)
    idx=vals.argsort()[0][-2]
    flat = vals.flatten()
    flat.sort()
    req_tfidf = flat[-2]
    if(req_tfidf==0):
        robo_response=robo_response+"I could not get you. I am still at a developing stage"
        return robo_response
    else:
        robo_response = robo_response+sent_tokens[idx]
        return robo_response
flag=True
print("K18HKbot: My name is K18HKBOT. I was created as a project by 4 students of LPU of K18HK. How can I help you?")
while(flag==True):
    user_response = raw_input()
    user_response=user_response.lower()
    if(user_response!='bye'):
        if(user_response=='thanks' or user_response=='thank you' ):
            flag=False
            print("K18HKbot: You are welcome..")
        else:
            if(greeting(user_response)!=None):
                print("K18HKbot: "+greeting(user_response))
            else:
                print("K18HKbot: ")
                print(response(user_response))
                sent_tokens.remove(user_response)
    else:
        flag=False
        print("K18HKbot: Bye! take care..")
